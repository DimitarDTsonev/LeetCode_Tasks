#include "catch2/catch_all.hpp"
#include "Dictionary.h"

//TODO Add your own unit tests to this file,
// or create additional files in this directory.

// TEST_CASE("Sample test")
// {
//     CHECK(true);
// }

TEST_CASE("Dictionary::erase() reduce the counter of the same prefix words")
{
	Dictionary dict;
	dict.insert("hello");
	dict.insert("hellooo");
	dict.erase("hello");
	REQUIRE(dict.contains("hellooo"));
	REQUIRE(dict.size() == 1);
}

TEST_CASE("Dictionary::erase() erase only the diffrent characters of the same prefix words")
{
	Dictionary dict;
	dict.insert("hello");
	dict.insert("hellooo");
	dict.erase("hellooo");
	REQUIRE(dict.contains("hello"));
	REQUIRE(dict.size() == 1);
}