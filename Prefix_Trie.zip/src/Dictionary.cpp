﻿#include "Dictionary.h"

#include <cctype> // Contains std::isalpha()
#include <cassert>

//TODO Implement the Dictionary class

void Dictionary::insert(const char* word)
{
	if (!isCorrectWord(word))
	{
		throw incorrect_word_exception();
	}

	Node* current = root;
	char curr{};
	int index{};
	while (*word)
	{
		curr = *word;
		if (std::isupper(curr))
		{
			curr = std::tolower(curr);
		}

		index = curr - 'a';

		if (index < 0 || index > 25)
		{
			throw incorrect_word_exception();
		}

		if (current->successors[index] == nullptr)
		{
			current->successors[index] = new Node();
		}

		current = current->successors[index];
		word++;
	}

	if (!current->isEndOfWord)
	{
		current->isEndOfWord = true;
		++wordCount;
	}
}

void Dictionary::erase(const char* word) noexcept
{
	if (isCorrectWord(word))
	{
		if (eraseHelper(root, word))
		{
			--wordCount;
		}
	}
}

bool Dictionary::contains(const char* word) const noexcept
{
	if (wordCount == 0 || isCorrectWord(word) == false)
	{
		return false;
	}

	const Node* current = root;
	char ch{};
	int index{};
	while (*word)
	{
		ch = *word;
		if (std::isupper(ch))
		{
			ch = std::tolower(ch);
		}

		index = ch - 'a';
		if (index < 0 || index > 25)
		{
			return false;
		}

		if (current->successors[index] == nullptr)
		{
			return false;
		}
		current = current->successors[index];
		++word;
	}
	return current->isEndOfWord;
}

size_t Dictionary::size() const noexcept
{
	return wordCount;
}

bool Dictionary::isCorrectWord(const char* word) noexcept
{
	if (word == nullptr || word[0] == '\0')
	{
		return false;
	}
	if (word[0] == '\0')
	{
		return false;
	}

	while (*word)
	{
		if (std::islower(*word) == 0 && std::isupper(*word) == 0)
		{
			return false;
		}
		++word;
	}

	return true;
}

bool Dictionary::eraseHelper(Node*& node, const char* word) noexcept
{
	if (*word == '\0')
	{
		if (node->isEndOfWord == false)
		{
			return false;
		}
		node->isEndOfWord = false;

		if (isEmptyNode(node) == true)
		{
			delete node;
			node = nullptr;
		}
		return true;
	}

	char ch = *word;
	if (std::isupper(ch))
	{
		ch = std::tolower(ch);
	}

	int index = ch - 'a';
	if (index < 0 || index > 25)
	{
		return false;
	}

	Node*& nextNode = node->successors[index];
	if (nextNode == nullptr || eraseHelper(nextNode, word + 1) == false)
	{
		return false;
	}

	if (isEmptyNode(node) == true && node->isEndOfWord == false)
	{
		delete node;
		node = nullptr;
	}

	return true;
}

bool Dictionary::isEmptyNode(Node* node) const noexcept
{
	for (Node* successor : node->successors)
	{
		if (successor != nullptr)
		{
			return false;
		}
	}
	
	return true;
}