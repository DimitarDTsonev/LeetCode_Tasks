#include "Dictionary.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <filesystem>

namespace fs = std::filesystem;

void displayUsage(const char* executablePath)
{
	try {
		fs::path ep(executablePath);

		std::cout
			<< "Usage:\n\t"
			<< ep.filename()
			<< " <dictionary> <filter> <text>"
			<< std::endl;
	}
	catch (...) {
		std::cout << "Cannot parse path from argv[0]";
	}
}

void loadDictionary(Dictionary& dictionary, const std::string& filePath, int& correctCount, int& incorrectCount)
{
	std::ifstream file(filePath);
	if (!file) 
	{
		std::cerr << "ERROR: Cannot open dictionary file: " << filePath << std::endl;
		exit(1);
	}

	std::cout << "Loading dictionary from " << filePath << "...\n";

	std::string line;
	int lineNumber = 0;

	while (std::getline(file, line)) 
	{
		if (line.empty() || line[0] == '#') continue;
		lineNumber++;

		try 
		{
			dictionary.insert(line.c_str());
			correctCount++;
		}
		catch (const incorrect_word_exception&) 
		{
			std::cout << "ERROR: incorrect entry \"" << line << "\" on line " << lineNumber << "\n";
			incorrectCount++;
		}
	}
	file.close();
}

void applyFilter(Dictionary& dictionary, const std::string& filePath, int& correctCount, int& incorrectCount, int& inDictionaryCount)
{
	std::ifstream file(filePath);
	if (!file) 
	{
		std::cerr << "ERROR: Cannot open filter file: " << filePath << std::endl;
		exit(1);
	}

	std::cout << "Removing the words listed at " << filePath << "...\n";

	std::string line;
	int lineNumber = 0;

	while (std::getline(file, line)) 
	{
		if (line.empty() || line[0] == '#') continue;

		lineNumber++;
		if (!Dictionary::isCorrectWord(line.c_str()))
		{
			std::cout << "ERROR: incorrect entry \"" << line << "\" on line " << lineNumber << "\n";
			incorrectCount++;
		}
		else 
		{
			if (dictionary.contains(line.c_str())) 
			{
				dictionary.erase(line.c_str());
				inDictionaryCount++;
			}
			correctCount++;
		}
	}
	file.close();
}

void verifyText(Dictionary& dictionary, const std::string& filePath, int& correctCount, int& incorrectCount)
{
	std::ifstream file(filePath);
	if (!file) 
	{
		std::cerr << "ERROR: Cannot open text file: " << filePath << std::endl;
		exit(1);
	}

	std::cout << "Verifying the contents of " << filePath << "...\n";

	std::string line;
	int lineNumber = 0;

	while (std::getline(file, line)) 
	{
		if (line.empty() || line[0] == '#') continue;
		lineNumber++;
		std::istringstream iss(line);
		std::string word;

		while (iss >> word) 
		{
			if (dictionary.contains(word.c_str())) 
			{
				correctCount++;
			}
			else 
			{
				std::cout << "SPELLING ERROR: \"" << word << "\" on line " << lineNumber << "\n";
				incorrectCount++;
			}
		}
	}
	file.close();
}

int main(int argc, char* argv[])
{
	if (argc < 4) 
	{
		displayUsage(argv[0]);
		return 0;
	}

	std::string dictionaryPath = argv[1];
	std::string filterPath = argv[2];
	std::string textPath = argv[3];

	Dictionary dictionary;
	int dictCorrectCount = 0, dictIncorrectCount = 0;
	int filterCorrectCount = 0, filterIncorrectCount = 0, filterInDictionaryCount = 0;
	int textCorrectCount = 0, textIncorrectCount = 0;

	loadDictionary(dictionary, dictionaryPath, dictCorrectCount, dictIncorrectCount);
	std::cout << std::endl;
	
	applyFilter(dictionary, filterPath, filterCorrectCount, filterIncorrectCount, filterInDictionaryCount);
	std::cout << std::endl;
	
	verifyText(dictionary, textPath, textCorrectCount, textIncorrectCount);
	std::cout << std::endl;
	
	std::cout << "\nStatistics:\n";
	std::cout << "    Dictionary entries: " << dictCorrectCount << " correct, " << dictIncorrectCount << " incorrect\n";
	std::cout << "        Filter entries: " << filterCorrectCount << " correct, " << filterIncorrectCount << " incorrect\n";
	std::cout << "  Resultant dictionary: " << dictCorrectCount - filterInDictionaryCount << std::endl;
	std::cout << "         Words in text: " << textCorrectCount << " correct, " << textIncorrectCount << " incorrect\n";

	return 0;
}