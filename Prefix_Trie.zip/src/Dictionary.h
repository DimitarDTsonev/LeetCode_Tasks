#pragma once

#include <stdexcept>
#include <unordered_set>

class incorrect_word_exception : public std::runtime_error 
{
public:
	incorrect_word_exception()
		: runtime_error("incorrect word")
	{
		// Nothing to do here
	}
};

class Dictionary 
{
public:
	Dictionary() : root(new Node()), wordCount(0) {}

	void insert(const char* word);
	void erase(const char* word) noexcept;
	bool contains(const char* word) const noexcept;
	size_t size() const noexcept;
	static bool isCorrectWord(const char* word) noexcept;

private:
	//TODO: Add your implementation details
	struct Node 
	{
		Node* successors['z' - 'a' + 1]{};
		bool isEndOfWord = false;

		Node() = default;

		~Node() {
			for (Node* successor : successors) 
			{
				delete successor;
			}
		}
	};

	Node* root{};
	size_t wordCount = 0;

	bool eraseHelper(Node*& node, const char* word) noexcept;
	bool isEmptyNode(Node* node) const noexcept;
};